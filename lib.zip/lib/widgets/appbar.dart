import 'package:flutter/material.dart';
import 'package:ionicons/ionicons.dart';
import '../../utils/constants.dart'as cs;

AppBar header(context) {
  return AppBar(
    title: Text('${cs.Constants.appName}'),
    centerTitle: true,
    actions: [Padding(
      padding: const EdgeInsets.only(right:20.0),
      child: Icon(Ionicons.notifications_outline),
    )],
  );
}
