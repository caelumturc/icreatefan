import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import '../../constants/widgets.dart';
import '../../models/popup_menu_model.dart';
import '../../screens/chat/chat_stream.dart';
import '../../constants/colors.dart';
import '../../provider/product_provider.dart';
import '../../services/user.dart';
import 'package:custom_pop_up_menu/custom_pop_up_menu.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
bool send = false;
class UserChatScreen extends StatefulWidget {
  static const String screenId = 'user_chat_screen';
  final String? chatroomId;
  const UserChatScreen({Key? key, this.chatroomId}) : super(key: key);

  @override
  State<UserChatScreen> createState() => _UserChatScreenState();
}

class _UserChatScreenState extends State<UserChatScreen> {
  File? _image;
  final picker = ImagePicker();
  bool isUploading = false;

  Future getImage() async {
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    setState(() {
      if (pickedFile != null) {
        _image = File(pickedFile.path);
        sendMessage();

      } else {
        print('No Image Selected');
      }
    });
  }
  TextEditingController msgController = TextEditingController();
  UserService firebaseUser = UserService();



  @override
  void dispose() {
    msgController.dispose();
    super.dispose();
  }

  sendMessage() async {
    // if (msgController.text.isNotEmpty) {
    //   FocusScope.of(context).unfocus();
    //   Map<String, dynamic> message = {
    //     'message': msgController.text,
    //     'sent_by': firebaseUser.user!.uid,
    //     'time': DateTime.now().microsecondsSinceEpoch,
    //   };
    //
    //   firebaseUser.createChat(chatroomId: widget.chatroomId, message: message);
    //   msgController.clear();
    // }
    // if (msgController.text.isNotEmpty || _image != null) {
    //   FocusScope.of(context).unfocus();
    //   Map<String, dynamic> message = {
    //     'message': msgController.text,
    //     'sent_by': firebaseUser.user!.uid,
    //     'time': DateTime.now().microsecondsSinceEpoch,
    //     'image_url':null,
    //   };
    //
    //   if (_image != null) {
    //
    //     message['image_url'] =     uploadFile(context, _image!.path).then((url) {
    //       if (url != null) {
    //         message["message"]="img";
    //         setState(() {
    //           isUploading = false;
    //           _image = null;
    //         });
    //       }
    //
    //   });
    //   firebaseUser.createChat(chatroomId: widget.chatroomId, message: message);
    //   msgController.clear();
    // }}
    if (msgController.text.isNotEmpty || _image != null) {
      FocusScope.of(context).unfocus();
      Map<String, dynamic> message = {
        'message': msgController.text,
        'sent_by': firebaseUser.user!.uid,
        'time': DateTime.now().microsecondsSinceEpoch,
        'image_url': null,
      };

      if (_image != null) {
        message['message'] = "Uploading image...";
        firebaseUser.createChat(chatroomId: widget.chatroomId, message: message);
        uploadFile(context, _image!.path).then((url) {
          if (url != null) {
            message['image_url'] = url;
            message['message'] = "img";
            firebaseUser.createChat(chatroomId: widget.chatroomId, message: message);
            CollectionReference messages =
            FirebaseFirestore.instance.collection('messages');
            messages
                .doc(widget.chatroomId)
                .collection('chats')
                .where("message", isEqualTo: "Uploading image...")
                .orderBy("time", descending: true)
                .limit(1)
                .get()
                .then((querySnapshot) {
              querySnapshot.docs[0].reference.delete();
            });
setState(() {
  _image=null;
});
          }
        });
      } else {
        firebaseUser.createChat(chatroomId: widget.chatroomId, message: message);
        msgController.clear();
      }
    }
  }

  @override
  void initState() {
    super.initState();
  }

  _body() {
    return Column(
      children: [
        Expanded(child:
        ChatStream(
          chatroomId: widget.chatroomId,
        )),
        Container(
          alignment: Alignment.bottomCenter,
          child: Container(
            decoration: BoxDecoration(
            //  color: whiteColor,
              border: Border(
                top: BorderSide(
                  color: disabledColor.withOpacity(0.2),
                ),
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      onChanged: (value) {
                        if (value.isNotEmpty) {
                          setState(() {
                            send = true;
                          });
                        } else {
                          setState(() {
                            send = false;
                          });
                        }
                      },
                      onSubmitted: (value) {
                        /// Pressing Enter and Sending Message Case
                        if (value.isNotEmpty) {
                          sendMessage();
                        }
                      },
                      controller: msgController,
                      style: TextStyle(
                     //   color: blackColor,
                      ),
                      decoration: InputDecoration(
                        hintText: 'Enter you message...',
                        hintStyle: TextStyle(
                       //   color: blackColor,
                        ),
                        border: InputBorder.none,
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: () {
                      getImage();
                    },
                    icon: const Icon(Icons.attach_file),
                  ),
                  Visibility(
                    visible: send,
                    child: IconButton(
                      onPressed: sendMessage,
                      icon: const Icon(Icons.send),
                    ),
                  ),
                ],
              ),
            ),
          ),
        )

      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    var productProvider = Provider.of<ProductProvider>(context);
    return Scaffold(
        appBar: AppBar(
        //  backgroundColor: whiteColor,
          elevation: 0,
          //iconTheme: IconThemeData(color: blackColor),
          title: Text(
            'Marketplace Chat ',
         //   style: TextStyle(color: blackColor),
          ),
          actions: [

            customPopUpMenu(
              context: context,
              chatroomId: widget.chatroomId,
            ),
          ],
        ),
        body: _body()
    // bottomNavigationBar:   Container(
    //   alignment: Alignment.bottomCenter,
    //   child: Container(
    //     decoration: BoxDecoration(
    //       color: whiteColor,
    //       border: Border(
    //         top: BorderSide(
    //           color: disabledColor.withOpacity(0.2),
    //         ),
    //       ),
    //     ),
    //     child: Padding(
    //       padding: const EdgeInsets.all(8.0),
    //       child: Row(
    //         children: [
    //           Expanded(
    //             child: TextField(
    //               onChanged: (value) {
    //                 if (value.isNotEmpty) {
    //                   setState(() {
    //                     send = true;
    //                   });
    //                 } else {
    //                   setState(() {
    //                     send = false;
    //                   });
    //                 }
    //               },
    //               onSubmitted: (value) {
    //                 /// Pressing Enter and Sending Message Case
    //                 if (value.isNotEmpty) {
    //                   sendMessage();
    //                 }
    //               },
    //               controller: msgController,
    //               style: TextStyle(
    //                 color: blackColor,
    //               ),
    //               decoration: InputDecoration(
    //                 hintText: 'Enter you message...',
    //                 hintStyle: TextStyle(
    //                   color: blackColor,
    //                 ),
    //                 border: InputBorder.none,
    //               ),
    //             ),
    //           ),
    //           IconButton(
    //             onPressed: () {
    //               getImage();
    //             },
    //             icon: const Icon(Icons.attach_file),
    //           ),
    //           Visibility(
    //             visible: send,
    //             child: IconButton(
    //               onPressed: sendMessage,
    //               icon: const Icon(Icons.send),
    //             ),
    //           ),
    //         ],
    //       ),
    //     ),
    //   ),
    // )
    );

  }

}
Future<String> uploadFile(BuildContext context, String filePath) async {
  String imageName = 'messages_image/${DateTime.now().microsecondsSinceEpoch}';
  String downloadUrl = '';
  final file = File(filePath);
  try {
    await FirebaseStorage.instance.ref(imageName).putFile(file);
    downloadUrl =
    await FirebaseStorage.instance.ref(imageName).getDownloadURL();
    print(downloadUrl);
  } on FirebaseException catch (e) {
    customSnackBar(context: context, content: e.code);
  }
  return downloadUrl;
}
