import 'package:flutter/material.dart';

Color primaryColor = const Color(0xff46a7e8);
Color secondaryColor = const Color(0xff035284);
// Color whiteColor = Colors.white;
// Color blackColor = Colors.black;
// Color? greyColor = Colors.grey[800];
Color disabledColor = const Color(0xff46a7e8);
Color errorColor = Colors.red;
Color linkColor = Color.fromARGB(255, 6, 97, 172);
