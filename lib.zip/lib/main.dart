import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:loxclone/utils/config.dart';
import 'package:provider/provider.dart';
import 'package:loxclone/components/life_cycle_event_handler.dart';
import 'package:loxclone/landing/landing_page.dart';
import 'package:loxclone/screens/mainscreen.dart';
import 'package:loxclone/services/user_service.dart';
import 'package:loxclone/utils/config.dart';
import 'package:loxclone/utils/constants.dart';
import 'package:loxclone/utils/providers.dart';
import 'package:loxclone/view_models/theme/theme_view_model.dart';

import 'advechile/forms/common_form.dart';
import 'advechile/forms/sell_car_form.dart';
import 'advechile/forms/user_form_review.dart';

import 'advechile/screens/category/category_list_screen.dart';
import 'advechile/screens/category/product_by_category_screen.dart';
import 'advechile/screens/category/subcategory_screen.dart';
import 'advechile/screens/chat/chat_screen.dart';
import 'advechile/screens/chat/user_chat_screen.dart';
import 'advechile/screens/home_screen.dart';
import 'advechile/screens/location_screen.dart';
import 'advechile/screens/main_navigatiion_screen.dart';
import 'advechile/screens/post/my_post_screen.dart';
import 'advechile/screens/product/product_details_screen.dart';
import 'advechile/screens/profile_screen.dart';
import 'advechile/screens/splash_screen.dart';


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Config.initFirebase();
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(
      LifecycleEventHandler(
        detachedCallBack: () => UserService().setUserStatus(false),
        resumeCallBack: () => UserService().setUserStatus(true),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // return MaterialApp(
    //     theme: ThemeData(
    //       primaryColor: blackColor,
    //       backgroundColor: whiteColor,
    //       fontFamily: 'Oswald',
    //       scaffoldBackgroundColor: whiteColor,
    //     ),
    //     debugShowCheckedModeBanner: false,
    //     initialRoute: SplashScreen.screenId,
    //     home: MultiProvider(
    //       providers: providers,
    //       child: Consumer<ThemeProvider>(
    //         builder: (context, ThemeProvider notifier, Widget? child) {
    //           return StreamBuilder(
    //             stream: FirebaseAuth.instance.authStateChanges(),
    //             builder: ((BuildContext context, snapshot) {
    //               if (snapshot.hasData) {
    //                 return TabScreen();
    //               } else
    //                 return Landing();
    //             }),
    //           );
    //         },
    //       ),
    //     ),
    //     routes: {
    //       SplashScreen.screenId: (context) => const SplashScreen(),
    //       LoginScreen.screenId: (context) => const LoginScreen(),
    //       PhoneAuthScreen.screenId: (context) => const PhoneAuthScreen(),
    //       LocationScreen.screenId: (context) => const LocationScreen(),
    //       HomeScreen.screenId: (context) => const HomeScreen(),
    //       WelcomeScreen.screenId: (context) => const WelcomeScreen(),
    //       RegisterScreen.screenId: (context) => const RegisterScreen(),
    //       EmailVerifyScreen.screenId: (context) => const EmailVerifyScreen(),
    //       ResetPasswordScreen.screenId: (context) => const ResetPasswordScreen(),
    //       CategoryListScreen.screenId: (context) => const CategoryListScreen(),
    //       SubCategoryScreen.screenId: (context) => const SubCategoryScreen(),
    //       MainNavigationScreen.screenId: (context) => const MainNavigationScreen(),
    //       ChatScreen.screenId: (context) => const ChatScreen(),
    //       MyPostScreen.screenId: (context) => const MyPostScreen(),
    //       ProfileScreen.screenId: (context) => const ProfileScreen(),
    //       SellCarForm.screenId: (context) => const SellCarForm(),
    //       UserFormReview.screenId: (context) => const UserFormReview(),
    //       CommonForm.screenId: (context) => const CommonForm(),
    //       ProductDetail.screenId: (context) => const ProductDetail(),
    //       ProductByCategory.screenId: (context) => const ProductByCategory(),
    //       UserChatScreen.screenId: (context) => const UserChatScreen(),
    //     });


    return MultiProvider(
      providers: providers,
      child: Consumer<ThemeProvider>(
        builder: (context, ThemeProvider notifier, Widget? child) {
          return MaterialApp(
            title: Constants.appName,
            debugShowCheckedModeBanner: false,
            theme: themeData(
              notifier.dark ? Constants.darkTheme : Constants.lightTheme,
            ),
            home: StreamBuilder(
              stream: FirebaseAuth.instance.authStateChanges(),
              builder: ((context, snapshot) {
                if (snapshot.hasData) {
                  return SplashScreen();
                } else
                  return SplashScreen();
              }),
            ),
              routes: {
                SplashScreen.screenId: (context) => const SplashScreen(),
                LocationScreen.screenId: (context) => const LocationScreen(),
                HomeScreen.screenId: (context) => const HomeScreen(),

                CategoryListScreen.screenId: (context) => const CategoryListScreen(),
                SubCategoryScreen.screenId: (context) => const SubCategoryScreen(),
                MainNavigationScreen.screenId: (context) =>
                const MainNavigationScreen(),
                ChatScreen.screenId: (context) => const ChatScreen(),
                MyPostScreen.screenId: (context) => const MyPostScreen(),
                ProfileScreen.screenId: (context) => const ProfileScreen(),
                SellCarForm.screenId: (context) => const SellCarForm(),
                UserFormReview.screenId: (context) => const UserFormReview(),
                CommonForm.screenId: (context) => const CommonForm(),
                ProductDetail.screenId: (context) => const ProductDetail(),
                ProductByCategory.screenId: (context) => const ProductByCategory(),
                UserChatScreen.screenId: (context) => const UserChatScreen(),
              }
          );
        },
      ),
    );
  }

  ThemeData themeData(ThemeData theme) {
    return theme.copyWith(
      textTheme: GoogleFonts.nunitoTextTheme(
        theme.textTheme,
      ),
    );
  }
}

