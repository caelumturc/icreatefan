enum MessageType {
  TEXT,
  IMAGE,
}
