import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:uuid/uuid.dart';

FirebaseAuth firebaseAuth = FirebaseAuth.instance;
FirebaseFirestore firestore = FirebaseFirestore.instance;
FirebaseStorage storage = FirebaseStorage.instance;
final Uuid uuid = Uuid();

// Collection refs
CollectionReference usersRef = firestore.collection('users');
CollectionReference chatRef = firestore.collection("main_chats");
CollectionReference postRef = firestore.collection('main_posts');
CollectionReference storyRef = firestore.collection('main_posts');
CollectionReference commentRef = firestore.collection('main_comments');
CollectionReference notificationRef = firestore.collection('main_notifications');
CollectionReference followersRef = firestore.collection('main_followers');
CollectionReference followingRef = firestore.collection('main_following');
CollectionReference likesRef = firestore.collection('main_likes');
CollectionReference favUsersRef = firestore.collection('main_favoriteUsers');
CollectionReference chatIdRef = firestore.collection('main_chatIds');
CollectionReference statusRef = firestore.collection('main_status');

// Storage refs
Reference profilePic = storage.ref().child('profilePic');
Reference posts = storage.ref().child('posts');
Reference statuses = storage.ref().child('status');
